@echo off
echo Stopping CodePilot Local Runtime...
taskkill /F /IM codepilot-runtime.exe 2>nul
echo CodePilot Local Runtime stopped.
