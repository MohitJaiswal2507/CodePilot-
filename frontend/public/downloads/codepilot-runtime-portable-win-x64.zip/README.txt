CodePilot Local Runtime (Portable Edition)
Version: 1.0.0

Quick Start:
1. Ensure Docker Desktop is running.
2. Double-click start-runtime.bat.
3. Open https://codepilot-frontend.vercel.app in your browser.
4. Click 'Runtime Not Installed' in the header to pair.
