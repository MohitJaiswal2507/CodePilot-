@echo off
echo Starting CodePilot Local Runtime on port 8088...
start "" /B "%~dp0codepilot-runtime.exe"
echo Runtime launched in background.
echo Access health at: http://127.0.0.1:8088/health
