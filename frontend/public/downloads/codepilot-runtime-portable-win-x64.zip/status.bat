@echo off
echo Checking CodePilot Local Runtime status...
curl.exe -s http://127.0.0.1:8088/status
echo.
pause
